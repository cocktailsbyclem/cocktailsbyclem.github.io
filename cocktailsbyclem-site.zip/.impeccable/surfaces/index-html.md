---
version: 1
slug: "index-html"
primary_target: "index.html"
related_targets: []
---

# Surface brief — index.html (site vitrine, page unique)

Scope: the whole public site, one scrolling page plus two legal sub-pages.
Visitor mode: **Persuade**.

Audience: someone planning an event around Clermont-Ferrand, arriving on a phone from
the `@cocktailsbyclem_` Instagram bio link. Job: decide in about a minute whether this
barman fits their event, then start a conversation with no friction.
Action: a free quote request, sent through WhatsApp, Instagram, or the form.
Proof on hand: the Instagram account, the real Latin American repertoire, five posts
supplied by the owner (two photographs, three post graphics), the seven watercolour
cocktail illustrations extracted from them, and the published per-cocktail prices.
Constraints: no testimonials, no email address, no photograph of Clem; none of these
may be invented. Static HTML/CSS/JS, no build step, mobile weight is the first
quality criterion.

## Direction contract

THESIS: The page is a printed cocktail carte, not an event-service landing page. It
refuses the category default wholesale: the grid of identical rounded icon-cards, the
stock tropical stripe, the pricing table, the hero of three statistics. Every block —
services, events, Clem himself, the contact rows — is set as an entry on a carte, so
the visitor is reading the thing the service actually produces from the first second.

OWN-WORLD: The palette is lifted from the account's own posts, sampled not guessed:
warm greige ground #D9CFC2, sage panel #B8B99C, pale lemon carte ground #E2E2C0,
cream #F4F1E6, sun yellow #FADF70 as a mark and a highlight pill only, deep forest
#1B3B24 for dark grounds and display ink, and one sparing ember #B9491C reserved
exclusively for the primary action so the eye learns that ember means "start a
conversation". The signature material is theirs: soft, heavily blurred botanical leaf
shadows cast across the warm ground, the single most recognizable trait of the feed.
Type follows the posts exactly — Cormorant Garamond in light all-caps at wide tracking
for display, its italic for cocktail recipes as the carte already sets them, DM Sans
for everything a hand touches. Components come from print and from their own layouts:
generously rounded sage panels, cream capsule headers, hairline rules, leader dots,
no UI-kit card shells, no drop shadow on content. Icons are authored line SVG at one
stroke weight. The seven watercolour cocktail glasses are extracted from the account's
own carte post and are the page's real illustration set.

STORY: The visitor understands within one viewport that a barman comes to their venue
and makes Latin American cocktails in front of their guests. They believe it because
they can read the actual repertoire — Pisco Sour, Chilcano, Caipirinha — not adjectives
about it. They do the one thing the page ever asks: request a free quote.

FIRST VIEWPORT: The account's own margarita photograph full-bleed behind a forest
veil, never a black scrim. The wordmark set in Cormorant light caps at display scale
with wide tracking, "Barman privé pour vos événements" beneath in tracked small caps,
then the promise line at reading size. Below them two actions on a sun-yellow hairline
that draws itself across: "Demander un devis" solid ember, "Voir les cocktails" ghost
on a hairline. Blurred leaf shadows drift over the veil under a very light parallax.
Sticky hairline header above with the wordmark, the nav, and the devis action at right.

FORM: The printed carte. Third on my ordered candidate list, dealt by the roll as card
3 of 6/7/3 under seed key cd3f1fe8. The roll ran degraded with no challengers. Its
lead, card 6, reorganises the page around an event-type chooser and card 7 around a
step-by-step ritual; both contradict the section order the user pinned explicitly in
the brief, and a brief-pinned decision beats the roll, so the carte takes the build.

FINISH: unreviewed and undocumented is unfinished; this build ends with the finish review, the verdict, DESIGN.md, and every shipping raster carrying its provenance.

## Unresolved

- Contact email address — placeholder in markup, marked for the owner.
- Photographs — every image is a named slot; the owner supplies files into `assets/`.
- Prices — absent by instruction; the tarifs section sells a bespoke quote instead.
- Google reviews — slot and button only, pending a Google Business Profile.
